<?php

if(!count($params))
{
  help();
  exit(1);
}

switch($params[0])
{
  case 'export':
    checkDir($dataDirectory);
    if(isset($sites)){
        foreach($sites as $siteUrl => $siteDirectory)
            {
              $exportPath = sprintf('%s/struct/%s', $dataDirectory, $siteDirectory);
              checkDir($exportPath);
              $cmd = sprintf('drush features-export %s  -y -l %s --destination=%s', PROJECT_NAME, $siteUrl, $exportPath);
              $status = taskExecute($cmd,"Exporting features...");
            }
    }
    else{

    }

    break;

  case 'import':
    foreach($sites as $siteUrl => $siteDirectory)
    {
    }
    break;

  case 'help':
  default:
    help();
}


function help()
{
  echo "Use 'export' or 'import' argument. Module features needed\n";
}